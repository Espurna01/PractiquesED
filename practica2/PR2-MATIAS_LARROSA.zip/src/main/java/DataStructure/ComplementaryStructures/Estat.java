package main.java.DataStructure.ComplementaryStructures;

public enum Estat{
    BLANC, GRIS, NEGRE;
}