package main.java.DataStructure.ComplementaryStructures;

public interface ID<I> {
    public I getId();
}
